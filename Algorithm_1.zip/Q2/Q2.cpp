#include<stdio.h>
int main( void ) 
{
	int row=10;
	printf("Enter a positive number:\n");
	scanf("%d",&row);
	for (int counter_y=1; counter_y != row + 1;counter_y++){
		for(int counter_x=counter_y;counter_x != row + 1;counter_x++){
			printf("%d",counter_x);
		}
		if(counter_y!=1){
			for(int counter_left=1;counter_left<counter_y;counter_left++){
			printf("%d",counter_left);
			}
		}
		printf("\n");
	}
}
